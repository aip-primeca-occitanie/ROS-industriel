# ros_rx60_workspace
ROS Pakete zur Simulation und Ansteuerung des RX60 Roboterarms der Hochschule Kaiserslautern
