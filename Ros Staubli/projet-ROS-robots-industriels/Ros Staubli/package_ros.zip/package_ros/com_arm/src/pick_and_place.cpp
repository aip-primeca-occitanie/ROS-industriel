/*
################
#### Entete ####
################
#
# This project has received funding from the European Union s Horizon 2020 research and innovation programme under grant agreement No 732287.
# The RIO project starts in Jan 2020 and ends in Dec 2020.
#
# Description du programme
#  -> Creation de la classe Recept : permet de souscrire à l un des trois topics publies par le noeud ROBOT et met a jour ses variables publiques 
#  (qui sont les memes que la classe Etat) avec les informations recues
#
# Entree
#  -> aucune
#
# Sortie 
#  -> aucune
#
# Historique
#  -> Creation: 29/09/2020, AIP PRIMECA Occitanie, Nathan MORET
#
######################
#### Fin d entete ####
######################
*/


#include "control.h"
#include "recept.h"
#include <ros/ros.h>
#include <string>
#include <iostream>
#include <com_arm/State.h>
#include <chrono>
#include <signal.h>
#include <stdlib.h>
#include <stdio.h>

sig_atomic_t volatile request_shutdown = 0;
Control* p_control;

void my_handler(int sig)
{
	request_shutdown = 1;
	p_control->stop();
	exit(0);
}

int main(int argc, char **argv)
{
	// Creation du noeud ROS
	ros::init(argc, argv, "pick_and_place", ros::init_options::NoSigintHandler);
	ros::NodeHandle noeud;
	
	signal (SIGINT,my_handler);
	
	// Importation des fonctions de contrôle
	Control control(noeud);
	p_control = &control;
	
	//////////////////////////////////////////////////////////
	
	/////////////////
	// Subscriber //
	////////////////
	
	std::string s = "/state";
	Recept state(noeud, s);
	
	//std::string j = "/joint";
	//Recept joint(noeud, j);
	
	//std::string c = "/cart";
	//Recept joint(noeud, c);
	
	///////////////////////////////////////////////////////////
	
	//////////////////
	// APPLICATION //
	/////////////////


	///****/// Joint  { j1, j2, j3, j4, j5, j6 }
	


	///****/// Cart  { x, y, z, rx, ry, rz }
	
	double init[6] = { 0, 0, 0, 0, 0, 0 };

	double prise1[6] = { 444.11, 63.99, -85.97, -0.14, 178.53, 1.26 };
	double appro1[6] = { 443.39, 63.99, -56.3, -0.14, 178.54, 1.26 };
	double posi1[6] = { 443.38, 63.98, 65.83, -0.14, 178.54, 1.26 };
	double prise2[6] = { 504.88, 63.98, -85.97, -0.14, 178.53, 1.26 };
	double appro2[6] = { 504.86, 63.98, -56.27, -0.14, 178.53, 1.25 };
	double posi2[6] = { 509.76, 63.95, 65.83, -0.15, 178.55, 1.26 };
	double prise3[6] = { 503.93, -72.75, -85.97, -0.15, 178.55, 1.26 };
	double appro3[6] = { 503.92, -72.75, -61.78, -0.15, 178.56, 1.26 };
	double posi3[6] = { 503.91, -72.74, 65.83, -0.14, 178.56, 1.26 };
	double prise4[6] = { 442.32, -100.11, -85.97, -0.15, 178.57, 1.26 };
	double appro4[6] = { 442.3, -100.11, -64.12, -0.15, 178.57, 1.26 };
	double posi4[6] = { 442.29, -100.1, 65.83, -0.14, 178.58, 1.26 };

	double transi[6] = { 185.77, -406.33, 65.83, -1.44, 179.73, 74.93 };
	double stock_posi[6] = { -386.56, -224.05, -65.83, 179.58, -1.41, -20.6 };
	double stock_appro_1[6] = { -386.56, -224.05, -302.81, 179.58, -1.41, -20.6 };
	double stock_prise_1[6] = { -386.56, -224.05, -312.81, 179.58, -1.41, -20.6 };
	double stock_appro_2[6] = { -386.56, -224.05, -255.81, 179.58, -1.41, -20.6 };
	double stock_prise_2[6] = { -386.56, -224.05, -265.81, 179.58, -1.41, -20.6 };

	double stock_appro_3[6] = { -386.56, -224.05, -208.81, 179.58, -1.41, -20.6 };
	double stock_prise_3[6] = { -386.56, -224.05, -218.81, 179.58, -1.41, -20.6 };

	double stock_appro_4[6] = { -386.56, -224.05, -161.81, 179.58, -1.41, -20.6 };
	double stock_prise_4[6] = { -386.56, -224.05, -171.81, 179.58, -1.41, -20.6 };


	///****/// Speed  { accel, vel, decel, tvel, rvel, blend, leave, reach }

	int fast[8] = { 100, 100, 100, 9999, 9999, 1, 100, 100 };
	int slow[8] = { 50, 50, 50, 100, 100, 0, 0, 0 };
	int fastb1[8] = { 100, 100, 100, 9999, 9999, 1, 5, 5 };
	int fastb2[8] = { 100, 100, 100, 9999, 9999, 1, 200, 100 };
	
	


	control.doTool("open");
	control.paramSpeed(fast);
	control.moveJoint(init);
	
	while (!request_shutdown)
	{	
		
		control.moveCartJ(posi1);
		control.moveCartL(appro1);
		control.paramSpeed(slow);
		control.moveCartL(prise1);
		control.doTool("close");
		control.moveCartL(appro1);
		control.paramSpeed(fast);
		control.moveCartL(posi1);
		
		control.moveCartC(stock_posi, transi);
		control.moveCartL(stock_appro_1);
		control.paramSpeed(slow);
		control.moveCartL(stock_prise_1);
		control.doTool("open");
		control.moveCartL(stock_appro_1);
		control.paramSpeed(fast);
		control.moveCartJ(stock_posi);
		
		control.moveCartC(posi2, transi);
		control.moveCartL(appro2);
		control.paramSpeed(slow);
		control.moveCartL(prise2);
		control.doTool("close");
		control.moveCartL(appro2);
		control.paramSpeed(fast);
		control.moveCartL(posi2);

		control.moveCartC(stock_posi, transi);
		control.moveCartL(stock_appro_2);
		control.paramSpeed(slow);
		control.moveCartL(stock_prise_2);
		control.doTool("open");
		control.moveCartL(stock_appro_2);
		control.paramSpeed(fast);
		control.moveCartJ(stock_posi);

		control.moveCartC(posi3, transi);
		control.moveCartL(appro3);
		control.paramSpeed(slow);
		control.moveCartL(prise3);
		control.doTool("close");
		control.moveCartL(appro3);
		control.paramSpeed(fast);
		control.moveCartL(posi3);

		control.moveCartC(stock_posi, transi);
		control.moveCartL(stock_appro_3);
		control.paramSpeed(slow);
		control.moveCartL(stock_prise_3);
		control.doTool("open");
		control.moveCartL(stock_appro_3);
		control.paramSpeed(fast);
		control.moveCartJ(stock_posi);

		control.moveCartC(posi4, transi);
		control.moveCartL(appro4);
		control.paramSpeed(slow);
		control.moveCartL(prise4);
		control.doTool("close");
		control.moveCartL(appro4);
		control.paramSpeed(fast);
		control.moveCartL(posi4);

		control.moveCartC(stock_posi, transi);
		control.moveCartL(stock_appro_4);
		control.paramSpeed(slow);
		control.moveCartL(stock_prise_4);
		control.doTool("open");
		control.moveCartL(stock_appro_4);
		control.paramSpeed(fast);
		control.moveCartJ(stock_posi);

		control.moveCartL(stock_appro_4);
		control.paramSpeed(slow);
		control.moveCartL(stock_prise_4);
		control.doTool("close");
		control.moveCartL(stock_appro_4);
		control.paramSpeed(fast);
		control.moveCartJ(stock_posi);

		control.moveCartC(posi2, transi);
		control.moveCartL(appro2);
		control.paramSpeed(slow);
		control.moveCartL(prise2);
		control.doTool("open");
		control.moveCartL(appro2);
		control.paramSpeed(fast);
		control.moveCartL(posi2);		
		
		control.moveCartC(stock_posi, transi);
		control.moveCartL(stock_appro_3);
		control.paramSpeed(slow);
		control.moveCartL(stock_prise_3);
		control.doTool("close");
		control.moveCartL(stock_appro_3);
		control.paramSpeed(fast);
		control.moveCartJ(stock_posi);

		control.moveCartC(posi1, transi);
		control.moveCartL(appro1);
		control.paramSpeed(slow);
		control.moveCartL(prise1);
		control.doTool("open");
		control.moveCartL(appro1);
		control.paramSpeed(fast);
		control.moveCartL(posi1);
		
		control.moveCartC(stock_posi, transi);
		control.moveCartL(stock_appro_2);
		control.paramSpeed(slow);
		control.moveCartL(stock_prise_2);
		control.doTool("close");
		control.moveCartL(stock_appro_2);
		control.paramSpeed(fast);
		control.moveCartJ(stock_posi);

		control.moveCartC(posi4, transi);
		control.moveCartL(appro4);
		control.paramSpeed(slow);
		control.moveCartL(prise4);
		control.doTool("open");
		control.moveCartL(appro4);
		control.paramSpeed(fast);
		control.moveCartL(posi4);

		control.moveCartC(stock_posi, transi);
		control.moveCartL(stock_appro_1);
		control.paramSpeed(slow);
		control.moveCartL(stock_prise_1);
		control.doTool("close");
		control.moveCartL(stock_appro_1);
		control.paramSpeed(fast);
		control.moveCartJ(stock_posi);

		control.moveCartC(posi3, transi);
		control.moveCartL(appro3);
		control.paramSpeed(slow);
		control.moveCartL(prise3);
		control.doTool("open");
		control.moveCartL(appro3);
		control.paramSpeed(fast);
		control.moveCartL(posi3);
		
	}
	return 0;
}




