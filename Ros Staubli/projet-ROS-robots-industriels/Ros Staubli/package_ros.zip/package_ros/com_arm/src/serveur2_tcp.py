#!/usr/bin/env python

import time
import socket
import rospy
import thread
from std_msgs.msg import String


 
######################tcp begining
HOST='169.254.207.220'
 
PORT=50001
 
BUFFER=4096
 
sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
 
sock.bind((HOST,PORT))

 
sock.listen(5)

 
################ros begining

rospy.init_node('serveur1_tcp',anonymous=True)
global coord
coord = ''
global envoi
envoi = 0


def callback(data):
	global coord
	global envoi
	coord = data.data
	if (coord != "n"):
		envoi = 1

def serveur():
	global coord
	global envoi
	print 'i am listening'
	
	
	#data = '393X309X225X-7X62X51XF'
	
	while not rospy.is_shutdown():
		buf = ''
		con,addr=sock.accept()
		try:
			con.settimeout(5)
			buf=con.recv(BUFFER)
			print(buf)
			time.sleep(1)
		except socket.timeout:
			print 'time out'
		con.send('L')
		print(coord)
		if (buf != ''):
			while 1 :
				buf=con.recv(BUFFER)
				print(buf)
		
	con.close()

def recept():
	rospy.Subscriber("poscart", String, callback)
	rospy.spin()

	

if __name__ == "__main__":
	thread.start_new_thread(serveur,())
	recept()
